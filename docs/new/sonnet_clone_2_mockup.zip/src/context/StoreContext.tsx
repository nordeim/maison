import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';
import type { Product } from '../data';

interface BagItem {
  product: Product;
}

interface StoreContextValue {
  cartCount: number;
  wishlist: Set<string>;
  bagItem: BagItem | null;
  bagVisible: boolean;
  cartBump: boolean;
  toastMessage: string | null;
  addToBag: (product: Product) => void;
  toggleWishlist: (product: Product) => void;
  showToast: (message: string) => void;
  closeBag: () => void;
  openCartToast: () => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cartCount, setCartCount] = useState(0);
  const [wishlist, setWishlist] = useState<Set<string>>(new Set());
  const [bagItem, setBagItem] = useState<BagItem | null>(null);
  const [bagVisible, setBagVisible] = useState(false);
  const [cartBump, setCartBump] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);
  const bagTimer = useRef<number | undefined>(undefined);

  const showToast = useCallback((message: string) => {
    window.clearTimeout(toastTimer.current);
    setToastMessage(message);
    toastTimer.current = window.setTimeout(() => setToastMessage(null), 2800);
  }, []);

  const closeBag = useCallback(() => {
    window.clearTimeout(bagTimer.current);
    setBagVisible(false);
  }, []);

  const addToBag = useCallback(
    (product: Product) => {
      setCartCount((count) => count + 1);
      setBagItem({ product });
      setBagVisible(true);
      setCartBump(true);
      window.setTimeout(() => setCartBump(false), 500);
      window.clearTimeout(bagTimer.current);
      bagTimer.current = window.setTimeout(() => setBagVisible(false), 5000);
    },
    [],
  );

  const toggleWishlist = useCallback(
    (product: Product) => {
      setWishlist((prev) => {
        const next = new Set(prev);
        if (next.has(product.id)) {
          next.delete(product.id);
          showToast('Removed from wishlist.');
        } else {
          next.add(product.id);
          showToast('Saved to wishlist.');
        }
        return next;
      });
    },
    [showToast],
  );

  const openCartToast = useCallback(() => {
    showToast(
      cartCount === 1 ? 'You have 1 item in your bag.' : `You have ${cartCount} items in your bag.`,
    );
  }, [cartCount, showToast]);

  return (
    <StoreContext.Provider
      value={{
        cartCount,
        wishlist,
        bagItem,
        bagVisible,
        cartBump,
        toastMessage,
        addToBag,
        toggleWishlist,
        showToast,
        closeBag,
        openCartToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within a StoreProvider');
  return ctx;
}
