import { ArrowRightIcon, HeartIcon } from './Icons';
import Reveal from './Reveal';
import { useStore } from '../context/StoreContext';
import { products, type Product } from '../data';
import { cn } from '../utils/cn';

function ProductCard({ product, delay }: { product: Product; delay: 1 | 2 | 3 | 4 }) {
  const { wishlist, toggleWishlist, addToBag } = useStore();
  const isWishlisted = wishlist.has(product.id);

  return (
    <Reveal as="article" variant="reveal-pop" delay={delay} className="product-card" >
      <div id={product.id} className="product-card__media">
        {product.badge && <span className="product-card__badge">{product.badge}</span>}
        <button
          type="button"
          className={cn('product-card__wishlist', isWishlisted && 'active')}
          aria-label={isWishlisted ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
          onClick={() => toggleWishlist(product)}
        >
          <HeartIcon />
        </button>
        <img className="product-card__img product-card__img--main" src={product.image} alt={product.name} loading="lazy" />
        <img className="product-card__img product-card__img--alt" src={product.altImage} alt="" loading="lazy" />
        <button type="button" className="product-card__quick-add" onClick={() => addToBag(product)}>
          Quick Add
        </button>
      </div>
      <span className="product-card__category">{product.category}</span>
      <h3 className="product-card__name">{product.name}</h3>
      <p className="product-card__material">{product.material}</p>
      <p className="product-card__price">${product.price}</p>
    </Reveal>
  );
}

export default function Products() {
  return (
    <section id="products" className="section">
      <div className="container">
        <div className="section-head">
          <Reveal className="head-text">
            <span className="eyebrow">The Collection</span>
            <h2 className="section-title">
              New arrivals, <em>made slowly</em>.
            </h2>
          </Reveal>
        </div>

        <div className="products__grid">
          {products.map((product, i) => (
            <ProductCard key={product.id} product={product} delay={((i % 4) + 1) as 1 | 2 | 3 | 4} />
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 'clamp(2.5rem, 5vw, 4rem)' }}>
          <a href="#footer" className="btn btn-outline">
            View All Products
            <ArrowRightIcon />
          </a>
        </div>
      </div>
    </section>
  );
}
