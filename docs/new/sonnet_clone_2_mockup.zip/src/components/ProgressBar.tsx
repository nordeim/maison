export default function ProgressBar({ progress }: { progress: number }) {
  return <div className="progress-bar" style={{ width: `${progress}%` }} aria-hidden="true" />;
}
