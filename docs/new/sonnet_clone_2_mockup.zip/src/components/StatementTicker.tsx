import { statementItems } from '../data';

export default function StatementTicker() {
  const items = [...statementItems, ...statementItems];
  return (
    <div className="statement section--tight" aria-hidden="true">
      <div className="statement__track">
        {items.map((item, i) => (
          <span key={`${item.text}-${i}`} style={{ display: 'flex', alignItems: 'center' }}>
            <span className={`statement__item statement__item--${item.variant}`}>{item.text}</span>
            <span className="statement__sep">&#10038;</span>
          </span>
        ))}
      </div>
    </div>
  );
}
