import { ArrowRightIcon } from './Icons';
import Reveal from './Reveal';
import { featuredImage } from '../data';

export default function FeaturedCollection() {
  return (
    <section className="section" style={{ background: 'var(--bg-2)' }}>
      <div className="container featured__grid">
        <Reveal variant="reveal-pop" className="featured__media">
          <img src={featuredImage} alt="Arc Pendant Light hanging above a dining table" loading="lazy" />
          <span className="featured__tag">Featured</span>
        </Reveal>

        <Reveal delay={2}>
          <span className="eyebrow">Featured Collection</span>
          <h2 className="section-title" style={{ marginBottom: '1.25rem', fontSize: 'clamp(2.25rem, 5vw, 3.75rem)' }}>
            Lighting that <em>casts warmth</em>.
          </h2>
          <p className="lede" style={{ marginBottom: '1.5rem' }}>
            Each fixture is shaped by hand from brass, ash, and blown glass, then paired with a
            warm, low-glare bulb chosen to flatter a room at dusk rather than flood it at noon.
          </p>
          <div className="featured__stats">
            <div className="stat">
              <span className="stat__value">28</span>
              <span className="stat__label">Pieces</span>
            </div>
            <div className="stat">
              <span className="stat__value">9</span>
              <span className="stat__label">Makers</span>
            </div>
            <div className="stat">
              <span className="stat__value">Brass &middot; Glass &middot; Clay</span>
              <span className="stat__label">Materials</span>
            </div>
          </div>
          <a href="#products" className="btn btn-outline">
            View Lighting
            <ArrowRightIcon />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
