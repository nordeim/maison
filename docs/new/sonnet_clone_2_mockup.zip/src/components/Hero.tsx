import { useEffect, useRef } from 'react';
import { ArrowRightIcon, ChevronDownIcon } from './Icons';
import { useMagnetic } from '../hooks';
import { heroImage, products } from '../data';

export default function Hero() {
  const bgRef = useRef<HTMLImageElement>(null);
  const magneticRef = useMagnetic<HTMLAnchorElement>();
  const spotlight = products[0];

  useEffect(() => {
    const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!fine || reduceMotion) return;

    const hero = document.getElementById('hero');
    const img = bgRef.current;
    if (!hero || !img) return;

    const onMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 14;
      const y = (e.clientY / window.innerHeight - 0.5) * 14;
      img.style.transform = `scale(1.1) translate(${x}px, ${y}px)`;
    };
    hero.addEventListener('mousemove', onMove);
    return () => hero.removeEventListener('mousemove', onMove);
  }, []);

  return (
    <section id="hero" className="hero">
      <div className="hero__bg">
        <img ref={bgRef} src={heroImage} alt="" fetchPriority="high" />
      </div>
      <div className="hero__overlay" />
      <div className="container hero__content">
        <span className="eyebrow eyebrow--on-dark hero__eyebrow">Autumn Collection &middot; 2026</span>
        <h1 className="hero__title">
          <span className="line">
            <span className="line-inner" style={{ animationDelay: '0.25s' }}>
              Objects of
            </span>
          </span>
          <span className="line">
            <span className="line-inner" style={{ animationDelay: '0.4s' }}>
              <em>quiet beauty</em>
            </span>
          </span>
        </h1>
        <p className="hero__desc">
          Slow-made furniture, lighting, textiles, and ceramics from Nordic artisans — crafted for
          rooms that ask to be lived in, not looked at.
        </p>
        <div className="hero__actions">
          <a ref={magneticRef} href="#products" className="btn btn-hero-primary magnetic">
            Shop the Collection
            <ArrowRightIcon />
          </a>
          <a href="#philosophy" className="btn btn-hero-outline">
            Our Philosophy
          </a>
        </div>
      </div>

      <a href={`#${spotlight.id}`} className="hero__spotlight">
        <img src={spotlight.image} alt={spotlight.name} width={56} height={56} />
        <div>
          <div className="hero__spotlight-name">{spotlight.name}</div>
          <div className="hero__spotlight-price">${spotlight.price}</div>
        </div>
      </a>

      <div className="hero__scroll-hint" aria-hidden="true">
        Scroll
        <ChevronDownIcon />
      </div>
    </section>
  );
}
