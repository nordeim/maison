import Reveal from './Reveal';
import { ClayVesselIcon, LinenWeaveIcon, OakLeafIcon } from './Icons';
import { materials, type Material } from '../data';

const ICONS: Record<Material['icon'], typeof OakLeafIcon> = {
  oak: OakLeafIcon,
  linen: LinenWeaveIcon,
  vessel: ClayVesselIcon,
};

const ACCENT_VAR: Record<Material['accent'], string> = {
  clay: 'var(--clay)',
  sage: 'var(--sage)',
  gold: 'var(--gold)',
};

export default function Materials() {
  return (
    <section id="materials" className="section">
      <div className="container">
        <div className="section-head">
          <Reveal className="head-text">
            <span className="eyebrow">Materials &amp; Origin</span>
            <h2 className="section-title">
              Three materials, <em>one standard</em>.
            </h2>
          </Reveal>
        </div>

        <div className="materials__grid">
          {materials.map((material, i) => {
            const Icon = ICONS[material.icon];
            return (
              <Reveal
                key={material.key}
                variant="reveal-pop"
                delay={((i % 4) + 1) as 1 | 2 | 3 | 4}
                as="article"
                className="material-card"
                style={{ ['--accent' as string]: ACCENT_VAR[material.accent] }}
              >
                <Icon className="material-card__icon" />
                <h3>{material.title}</h3>
                <p>{material.paragraph}</p>
                <span className="material-card__origin">{material.origin}</span>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
