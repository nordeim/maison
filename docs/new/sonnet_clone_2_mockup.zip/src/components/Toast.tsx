import { useStore } from '../context/StoreContext';
import { cn } from '../utils/cn';

export default function Toast() {
  const { toastMessage } = useStore();
  return (
    <div className={cn('toast', toastMessage && 'show')} role="status" aria-live="polite">
      {toastMessage}
    </div>
  );
}
