import { ArrowRightIcon } from './Icons';
import Reveal from './Reveal';
import { categories } from '../data';

export default function Categories() {
  return (
    <section id="categories" className="section">
      <div className="container">
        <div className="section-head">
          <Reveal className="head-text">
            <span className="eyebrow">Shop by Category</span>
            <h2 className="section-title">
              Every room, <em>considered</em>.
            </h2>
          </Reveal>
          <Reveal delay={2}>
            <a href="#products" className="link">
              View all categories &rarr;
            </a>
          </Reveal>
        </div>

        <div className="categories__grid">
          {categories.map((cat, i) => (
            <Reveal
              key={cat.key}
              variant="reveal-pop"
              delay={((i % 4) + 1) as 1 | 2 | 3 | 4}
              className={`category-card category-card--${cat.area}`}
            >
              <a href="#products" className="category-card__link">
                <img src={cat.image} alt={cat.name} loading="lazy" />
                <div className="category-card__overlay" />
                <div className="category-card__content">
                  <h3 className="category-card__title">{cat.name}</h3>
                  <span className="category-card__count">
                    {cat.count} pieces
                    <ArrowRightIcon />
                  </span>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
