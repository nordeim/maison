import { InstagramIcon } from './Icons';
import Reveal from './Reveal';
import { instagramImages } from '../data';

export default function InstagramGrid() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-head section-head--center">
          <Reveal className="head-text">
            <span className="eyebrow">Follow Along</span>
            <h2 className="section-title">
              @maison<em>living</em>
            </h2>
            <p className="lede" style={{ marginTop: '1rem', marginInline: 'auto' }}>
              Tag your space with #maisonliving for a chance to be featured — a running record of
              how our objects settle into real homes.
            </p>
          </Reveal>
        </div>

        <div className="instagram__grid">
          {instagramImages.map((src, i) => (
            <Reveal
              key={src}
              variant="reveal-pop"
              delay={((i % 4) + 1) as 1 | 2 | 3 | 4}
              className="instagram-item"
            >
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="instagram-item__link" aria-label="View post on Instagram">
                <img src={src} alt="" loading="lazy" />
                <div className="instagram-item__overlay">
                  <InstagramIcon />
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
