import { useEffect, useState } from 'react';
import { AccountIcon, CartIcon, CloseIcon, SearchIcon } from './Icons';
import { useStore } from '../context/StoreContext';
import { cn } from '../utils/cn';

const NAV_LINKS = [
  { label: 'Furniture', href: '#categories' },
  { label: 'Lighting', href: '#categories' },
  { label: 'Textiles', href: '#products' },
  { label: 'Journal', href: '#journal' },
  { label: 'Our Story', href: '#philosophy' },
];

const HELP_LINKS = [
  { label: 'Shipping & Returns', href: '#footer' },
  { label: 'Care Guides', href: '#materials' },
  { label: 'Contact Us', href: '#footer' },
];

export default function Header({ scrolled }: { scrolled: boolean }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { cartCount, cartBump, openCartToast } = useStore();

  useEffect(() => {
    document.body.classList.toggle('no-scroll', menuOpen);
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [menuOpen]);

  return (
    <>
      <div className="announcement-bar" role="banner">
        Complimentary shipping on orders over <em>$150</em> — through the season
      </div>

      <header className={cn('site-header', scrolled && 'scrolled')} aria-label="Site header">
        <div className="container header__inner">
          <a href="#top" className="logo" aria-label="Maison home">
            M<em>a</em>ison
          </a>

          <nav className="header__nav" aria-label="Primary">
            {NAV_LINKS.map((link) => (
              <a key={link.label} href={link.href}>
                {link.label}
              </a>
            ))}
          </nav>

          <div className="header__actions">
            <button type="button" className="icon-btn hide-mobile" aria-label="Search">
              <SearchIcon />
            </button>
            <button type="button" className="icon-btn hide-mobile" aria-label="Account">
              <AccountIcon />
            </button>
            <button type="button" className="icon-btn" aria-label="Cart" onClick={openCartToast}>
              <CartIcon />
              {cartCount > 0 && (
                <span className={cn('cart-badge', cartBump && 'bump')}>{cartCount}</span>
              )}
            </button>
            <button
              type="button"
              className={cn('hamburger', menuOpen && 'open')}
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((v) => !v)}
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
      </header>

      <div
        className={cn('mobile-nav-overlay', menuOpen && 'open')}
        onClick={() => setMenuOpen(false)}
        aria-hidden="true"
      />
      <nav
        className={cn('mobile-nav', menuOpen && 'open')}
        aria-label="Mobile navigation"
        aria-hidden={!menuOpen}
      >
        <div className="mobile-nav__head">
          <span className="logo" style={{ fontSize: '1.3rem' }}>
            M<em>a</em>ison
          </span>
          <button type="button" className="icon-btn" aria-label="Close menu" onClick={() => setMenuOpen(false)}>
            <CloseIcon />
          </button>
        </div>
        <div className="mobile-nav__section">
          <span className="mobile-nav__label">Menu</span>
          <div className="mobile-nav__links">
            {NAV_LINKS.map((link) => (
              <a key={link.label} href={link.href} onClick={() => setMenuOpen(false)}>
                {link.label}
              </a>
            ))}
          </div>
        </div>
        <div className="mobile-nav__section">
          <span className="mobile-nav__label">Help</span>
          <div className="mobile-nav__links">
            {HELP_LINKS.map((link) => (
              <a key={link.label} href={link.href} onClick={() => setMenuOpen(false)}>
                {link.label}
              </a>
            ))}
          </div>
        </div>
      </nav>
    </>
  );
}
