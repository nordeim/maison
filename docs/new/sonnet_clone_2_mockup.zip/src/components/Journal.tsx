import Reveal from './Reveal';
import { journalPosts } from '../data';

export default function Journal() {
  return (
    <section id="journal" className="section" style={{ background: 'var(--bg-2)' }}>
      <div className="container">
        <div className="section-head">
          <Reveal className="head-text">
            <span className="eyebrow">The Journal</span>
            <h2 className="section-title">
              Notes on <em>slow living</em>.
            </h2>
          </Reveal>
        </div>

        <div className="journal__grid">
          {journalPosts.map((post, i) => (
            <Reveal
              as="article"
              key={post.title}
              variant="reveal-pop"
              delay={((i % 4) + 1) as 1 | 2 | 3 | 4}
              className="journal-card"
            >
              <div className="journal-card__media">
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <span className="journal-card__meta">
                <em>{post.category}</em> &middot; {post.readTime}
              </span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
