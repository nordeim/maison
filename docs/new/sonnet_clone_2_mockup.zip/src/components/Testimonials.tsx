import Reveal from './Reveal';
import { testimonials } from '../data';

export default function Testimonials() {
  const cards = [...testimonials, ...testimonials];
  return (
    <section className="section">
      <div className="container">
        <div className="section-head section-head--center">
          <Reveal className="head-text">
            <span className="eyebrow">In Their Homes</span>
            <h2 className="section-title">
              Stories from <em>quiet</em> rooms.
            </h2>
          </Reveal>
        </div>
      </div>

      <div className="testimonials-wrap">
        <div className="testimonials__track">
          {cards.map((t, i) => (
            <article className="testimonial-card" key={`${t.name}-${i}`} aria-hidden={i >= testimonials.length}>
              <span className="testimonial-card__quote" aria-hidden="true">
                &ldquo;
              </span>
              <div className="testimonial-card__stars" aria-label="5 out of 5 stars">
                &#9733;&#9733;&#9733;&#9733;&#9733;
              </div>
              <blockquote>{t.quote}</blockquote>
              <cite>
                <span>
                  {t.name} &nbsp;<span className="location">{t.location}</span>
                </span>
              </cite>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
