import { InstagramIcon, PinterestIcon, YoutubeIcon } from './Icons';

const FOOTER_COLUMNS = [
  {
    title: 'Shop',
    links: ['Furniture', 'Lighting', 'Textiles', 'Ceramics', 'Gift Cards'],
  },
  {
    title: 'About',
    links: ['Our Story', 'Our Makers', 'Materials', 'Journal', 'Sustainability'],
  },
  {
    title: 'Help',
    links: ['Shipping & Returns', 'Care Guides', 'Warranty', 'FAQs', 'Contact Us'],
  },
];

const LEGAL_LINKS = ['Privacy Policy', 'Terms of Service', 'Cookie Settings'];

export default function Footer() {
  return (
    <footer id="footer" className="site-footer">
      <div className="container">
        <div className="footer__top">
          <div className="footer__brand">
            <span className="logo">
              M<em>a</em>ison
            </span>
            <p>
              Curated home objects and lifestyle pieces — crafted by Nordic artisans for
              intentional, serene living since 1998.
            </p>
            <div className="footer__social">
              <a className="social-btn" href="https://instagram.com" aria-label="Maison on Instagram">
                <InstagramIcon />
              </a>
              <a className="social-btn" href="https://pinterest.com" aria-label="Maison on Pinterest">
                <PinterestIcon />
              </a>
              <a className="social-btn" href="https://youtube.com" aria-label="Maison on YouTube">
                <YoutubeIcon />
              </a>
            </div>
          </div>

          {FOOTER_COLUMNS.map((col) => (
            <div className="footer__col" key={col.title}>
              <h4>{col.title}</h4>
              {col.links.map((link) => (
                <a key={link} href="#top">
                  {link}
                </a>
              ))}
            </div>
          ))}
        </div>

        <div className="footer__bottom">
          <span>&copy; {new Date().getFullYear()} Maison. All rights reserved.</span>
          <div className="legal-links">
            {LEGAL_LINKS.map((link) => (
              <a key={link} href="#top">
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
