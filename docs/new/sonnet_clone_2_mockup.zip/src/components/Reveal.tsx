import type { CSSProperties, ElementType, ReactNode } from 'react';
import { useReveal } from '../hooks';
import { cn } from '../utils/cn';

interface RevealProps {
  as?: ElementType;
  variant?: 'reveal' | 'reveal-pop';
  delay?: 1 | 2 | 3 | 4;
  className?: string;
  style?: CSSProperties;
  children: ReactNode;
}

/** Wraps content in the mockup's scroll-triggered reveal treatment. */
export default function Reveal({ as: Tag = 'div', variant = 'reveal', delay, className, style, children }: RevealProps) {
  const [ref, visible] = useReveal<HTMLDivElement>();
  return (
    <Tag
      ref={ref}
      data-delay={delay}
      style={style}
      className={cn(variant, visible && 'visible', className)}
    >
      {children}
    </Tag>
  );
}
