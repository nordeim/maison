import { type FormEvent, useState } from 'react';
import Reveal from './Reveal';
import { useStore } from '../context/StoreContext';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Newsletter() {
  const { showToast } = useStore();
  const [email, setEmail] = useState('');

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!EMAIL_PATTERN.test(email)) {
      showToast('Please enter a valid email address.');
      return;
    }
    showToast('Thank you for subscribing to Letters from Maison.');
    setEmail('');
  }

  return (
    <section className="newsletter">
      <div className="container-narrow newsletter__inner">
        <Reveal>
          <span className="eyebrow eyebrow--on-dark">Stay Close</span>
          <h2 className="section-title section-title--on-dark" style={{ fontSize: 'clamp(2.25rem, 5vw, 3.5rem)' }}>
            Letters from <em>Maison</em>.
          </h2>
          <p className="newsletter__intro">
            Considered notes on new arrivals, maker profiles, and the quiet rituals of a
            well-tended home — sent once every few weeks, never more.
          </p>
          <form className="newsletter__form" onSubmit={handleSubmit} noValidate>
            <label htmlFor="newsletter-email" className="sr-only" style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }}>
              Email address
            </label>
            <input
              id="newsletter-email"
              className="newsletter__input"
              type="email"
              placeholder="Your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
            />
            <button type="submit" className="newsletter__submit">
              Subscribe
            </button>
          </form>
          <p className="newsletter__legal">
            By subscribing you agree to our Privacy Policy. Unsubscribe anytime.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
