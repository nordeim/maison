import { CloseIcon } from './Icons';
import { useStore } from '../context/StoreContext';
import { cn } from '../utils/cn';

export default function BagPanel() {
  const { bagItem, bagVisible, cartCount, closeBag } = useStore();

  return (
    <div className={cn('bag-panel', bagVisible && 'show')} role="status" aria-live="polite" aria-hidden={!bagVisible}>
      <div className="bag-panel__head">
        <span>Added to Bag</span>
        <button type="button" className="icon-btn" aria-label="Close" onClick={closeBag} style={{ width: 28, height: 28 }}>
          <CloseIcon style={{ width: 12, height: 12 }} />
        </button>
      </div>
      {bagItem && (
        <div className="bag-panel__body">
          <img src={bagItem.product.image} alt={bagItem.product.name} />
          <div>
            <div className="bag-panel__name">{bagItem.product.name}</div>
            <div className="bag-panel__meta">${bagItem.product.price}</div>
            <div className="bag-panel__meta">
              {cartCount} item{cartCount === 1 ? '' : 's'} in bag
            </div>
          </div>
        </div>
      )}
      <div className="bag-panel__foot">
        <a href="#products" className="link" onClick={closeBag}>
          View Bag &rarr;
        </a>
      </div>
    </div>
  );
}
