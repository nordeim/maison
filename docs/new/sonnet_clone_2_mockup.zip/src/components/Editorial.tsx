import { ArrowRightIcon } from './Icons';
import Reveal from './Reveal';
import { editorialImage } from '../data';

export default function Editorial() {
  return (
    <section className="editorial">
      <div className="editorial__bg">
        <img src={editorialImage} alt="A warm, firelit living room at dusk" loading="lazy" />
      </div>
      <div className="editorial__overlay" />
      <div className="container">
        <Reveal className="editorial__content">
          <span className="eyebrow eyebrow--on-dark">The Editorial</span>
          <h2 className="section-title section-title--on-dark" style={{ fontSize: 'clamp(2.25rem, 5.5vw, 4rem)' }}>
            A room is a <em>feeling</em>.
          </h2>
          <p>
            Light low. Wood warm underfoot. A single vessel on the shelf, not ten. Our styling
            philosophy is the same as our making philosophy: fewer things, chosen with care, given
            room to breathe.
          </p>
          <a href="#journal" className="btn btn-editorial">
            Read the Journal
            <ArrowRightIcon />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
