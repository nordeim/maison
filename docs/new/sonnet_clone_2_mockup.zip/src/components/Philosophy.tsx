import { ArrowRightIcon } from './Icons';
import Reveal from './Reveal';
import { philosophyImages } from '../data';

export default function Philosophy() {
  return (
    <section id="philosophy" className="philosophy">
      <div className="mesh-glow" aria-hidden="true" />
      <div className="container philosophy__grid">
        <Reveal variant="reveal-pop" className="philosophy__images">
          <div className="philosophy__image philosophy__image--tall">
            <img src={philosophyImages.tall} alt="A calm, considered living room styled with oak and linen" loading="lazy" />
          </div>
          <div className="philosophy__image">
            <img src={philosophyImages.square1} alt="A maker planing oak by hand in the workshop" loading="lazy" />
          </div>
          <div className="philosophy__image">
            <img src={philosophyImages.square2} alt="A carpenter measuring timber in the workshop" loading="lazy" />
          </div>
        </Reveal>

        <Reveal delay={2} className="philosophy__text">
          <span className="eyebrow">Our Philosophy</span>
          <h2 className="section-title" style={{ marginBottom: '1.25rem' }}>
            A home should be <em>honest</em>, not <em>hurried</em>.
          </h2>
          <p>
            We believe an object earns its place in a home slowly — through the hand that shaped
            it, the material it was shaped from, and the years it is asked to endure. Every piece
            we carry is made by a Nordic maker we know by name.
          </p>
          <p>
            No pressed particleboard, no synthetic fills, no next-day guilt. Just oak, linen, wool,
            and clay — sourced honestly, finished by hand, and built to be repaired rather than
            replaced.
          </p>

          <div className="philosophy__ornament" aria-hidden="true">
            <span />
            <span className="star">&#10038;</span>
            <span />
          </div>

          <div className="philosophy__stats">
            <div className="stat">
              <span className="stat__value">27</span>
              <span className="stat__label">Years in craft</span>
            </div>
            <div className="stat">
              <span className="stat__value">14</span>
              <span className="stat__label">Nordic makers</span>
            </div>
            <div className="stat">
              <span className="stat__value">100%</span>
              <span className="stat__label">FSC oak</span>
            </div>
          </div>

          <a href="#materials" className="btn btn-outline">
            Meet Our Makers
            <ArrowRightIcon />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
