import { brandMarqueeItems } from '../data';

export default function BrandMarquee() {
  const items = [...brandMarqueeItems, ...brandMarqueeItems];
  return (
    <div className="marquee" aria-hidden="true">
      <div className="marquee__track">
        {items.map((item, i) => (
          <span className="marquee__item" key={`${item}-${i}`}>
            <span className="diamond">&#9670;</span>
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
