export interface Product {
  id: string;
  name: string;
  category: string;
  material: string;
  price: number;
  badge?: 'New' | 'Bestseller';
  image: string;
  altImage: string;
}

export const products: Product[] = [
  {
    id: 'arc-pendant-light',
    name: 'Arc Pendant Light',
    category: 'Lighting',
    material: 'Hand-bent brass & Belgian linen',
    price: 485,
    badge: 'Bestseller',
    image: 'https://images.pexels.com/photos/32456129/pexels-photo-32456129.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/36265889/pexels-photo-36265889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'halden-armchair',
    name: 'Halden Armchair',
    category: 'Furniture',
    material: 'Solid FSC oak & wool boucle',
    price: 1240,
    badge: 'New',
    image: 'https://images.pexels.com/photos/7602900/pexels-photo-7602900.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/29402568/pexels-photo-29402568.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'flax-table-runner',
    name: 'Flax Table Runner',
    category: 'Textiles',
    material: 'Stonewashed Normandy flax',
    price: 68,
    image: 'https://images.pexels.com/photos/5908241/pexels-photo-5908241.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/30618181/pexels-photo-30618181.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'aria-stoneware-vase',
    name: 'Aria Stoneware Vase',
    category: 'Ceramics',
    material: 'Hand-thrown Gothenburg stoneware',
    price: 128,
    image: 'https://images.pexels.com/photos/7663201/pexels-photo-7663201.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/29904622/pexels-photo-29904622.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'nordic-floor-lamp',
    name: 'Nordic Floor Lamp',
    category: 'Lighting',
    material: 'Oiled ash & handblown glass',
    price: 610,
    image: 'https://images.pexels.com/photos/36265889/pexels-photo-36265889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/32456129/pexels-photo-32456129.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'oak-dining-chair',
    name: 'Oak Dining Chair',
    category: 'Furniture',
    material: 'Steam-bent Småland oak',
    price: 385,
    image: 'https://images.pexels.com/photos/29402568/pexels-photo-29402568.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/7602900/pexels-photo-7602900.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'linen-cushion-cover',
    name: 'Linen Cushion Cover',
    category: 'Textiles',
    material: 'Washed heavyweight linen',
    price: 54,
    badge: 'New',
    image: 'https://images.pexels.com/photos/20191563/pexels-photo-20191563.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/5908241/pexels-photo-5908241.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
  {
    id: 'glaze-ceramic-bowl',
    name: 'Glaze Ceramic Bowl',
    category: 'Ceramics',
    material: 'Reactive glaze stoneware',
    price: 96,
    image: 'https://images.pexels.com/photos/29286721/pexels-photo-29286721.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
    altImage: 'https://images.pexels.com/photos/7663201/pexels-photo-7663201.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=800',
  },
];

export interface Category {
  key: string;
  name: string;
  count: number;
  image: string;
  area: 'feature' | 'wide' | 'small1' | 'small2';
}

export const categories: Category[] = [
  {
    key: 'furniture',
    name: 'Furniture',
    count: 42,
    area: 'feature',
    image: 'https://images.pexels.com/photos/8251559/pexels-photo-8251559.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=1400',
  },
  {
    key: 'lighting',
    name: 'Lighting',
    count: 28,
    area: 'wide',
    image: 'https://images.pexels.com/photos/36265889/pexels-photo-36265889.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600',
  },
  {
    key: 'textiles',
    name: 'Textiles',
    count: 19,
    area: 'small1',
    image: 'https://images.pexels.com/photos/30618181/pexels-photo-30618181.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900',
  },
  {
    key: 'ceramics',
    name: 'Ceramics',
    count: 24,
    area: 'small2',
    image: 'https://images.pexels.com/photos/27584189/pexels-photo-27584189.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900',
  },
];

export interface Material {
  key: string;
  title: string;
  accent: 'clay' | 'sage' | 'gold';
  icon: 'oak' | 'linen' | 'vessel';
  paragraph: string;
  origin: string;
}

export const materials: Material[] = [
  {
    key: 'oak',
    title: 'FSC Oak',
    accent: 'clay',
    icon: 'oak',
    paragraph:
      'Solid oak from sustainably managed forests in southern Sweden, kiln-dried and finished with raw beeswax so the grain deepens honestly with age.',
    origin: 'Origin: Småland, Sweden',
  },
  {
    key: 'linen',
    title: 'European Linen',
    accent: 'sage',
    icon: 'linen',
    paragraph:
      'Stonewashed flax woven on century-old looms, left undyed or finished with low-impact pigments that soften with every wash.',
    origin: 'Origin: Normandy, France',
  },
  {
    key: 'clay',
    title: 'Hand-thrown Clay',
    accent: 'gold',
    icon: 'vessel',
    paragraph:
      'Stoneware thrown by hand and fired twice with reactive glazes, so no two pieces — and no two meals eaten from them — are quite the same.',
    origin: 'Origin: Gothenburg, Sweden',
  },
];

export interface Testimonial {
  quote: string;
  name: string;
  location: string;
}

export const testimonials: Testimonial[] = [
  {
    quote:
      'The Halden armchair arrived fully assembled and feels like it was made for our living room. Six months on, it still smells faintly of oil and oak.',
    name: 'Freja L.',
    location: 'Copenhagen, DK',
  },
  {
    quote:
      'Every piece we have bought from Maison ages better than the day it arrived. The linen has softened, the oak has darkened — exactly as they said it would.',
    name: 'Anders M.',
    location: 'Oslo, NO',
  },
  {
    quote:
      'Considered, quiet, and honest about where things come from. The Aria vase is the first thing guests ask about.',
    name: 'Ingrid S.',
    location: 'Stockholm, SE',
  },
  {
    quote:
      'I have furnished two homes with Maison now. Slow shipping, but you can feel the difference in the joinery.',
    name: 'Marcus T.',
    location: 'Helsinki, FI',
  },
  {
    quote:
      'The Arc pendant is the calmest light in our home — warm, low, and never harsh. Worth the wait.',
    name: 'Elin R.',
    location: 'Gothenburg, SE',
  },
];

export interface JournalPost {
  category: string;
  readTime: string;
  title: string;
  excerpt: string;
  image: string;
}

export const journalPosts: JournalPost[] = [
  {
    category: 'Craft',
    readTime: '6 min read',
    title: 'Why oak gets better with age',
    excerpt:
      'A short guide to oiling, brushing, and accepting the small marks a piece will gather over a decade of use.',
    image: 'https://images.pexels.com/photos/5974239/pexels-photo-5974239.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200',
  },
  {
    category: 'Living',
    readTime: '4 min read',
    title: 'Styling a quiet bedroom corner',
    excerpt:
      'Layering linen, low light, and a single ceramic form to make a small room feel like a sanctuary.',
    image: 'https://images.pexels.com/photos/36411723/pexels-photo-36411723.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200',
  },
  {
    category: 'Philosophy',
    readTime: '5 min read',
    title: 'The case for fewer, better things',
    excerpt:
      'On buying once, buying well, and letting objects earn their place in a home over years, not seasons.',
    image: 'https://images.pexels.com/photos/14063721/pexels-photo-14063721.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200',
  },
];

export const instagramImages: string[] = [
  'https://images.pexels.com/photos/19884207/pexels-photo-19884207.png?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600',
  'https://images.pexels.com/photos/29904622/pexels-photo-29904622.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600',
  'https://images.pexels.com/photos/32541183/pexels-photo-32541183.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600',
  'https://images.pexels.com/photos/18063845/pexels-photo-18063845.png?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600',
  'https://images.pexels.com/photos/13344056/pexels-photo-13344056.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600',
  'https://images.pexels.com/photos/5793641/pexels-photo-5793641.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600',
];

export const brandMarqueeItems: string[] = [
  'Handcrafted in Scandinavia',
  'FSC-certified Oak',
  'Carbon-neutral Delivery',
  '10-year Guarantee',
  'Plant-based Textiles',
];

export const statementItems: { text: string; variant: 'solid' | 'outline' }[] = [
  { text: 'Slow-made', variant: 'solid' },
  { text: 'Honest materials', variant: 'outline' },
  { text: 'Made to last', variant: 'outline' },
];

export const heroImage =
  'https://images.pexels.com/photos/36777855/pexels-photo-36777855.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=2200';

export const editorialImage =
  'https://images.pexels.com/photos/7745945/pexels-photo-7745945.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=2200';

export const featuredImage =
  'https://images.pexels.com/photos/32456129/pexels-photo-32456129.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=960';

export const philosophyImages = {
  tall: 'https://images.pexels.com/photos/8251559/pexels-photo-8251559.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=1000',
  square1: 'https://images.pexels.com/photos/5974239/pexels-photo-5974239.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=800',
  square2: 'https://images.pexels.com/photos/6790027/pexels-photo-6790027.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=800',
};
