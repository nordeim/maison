import BagPanel from './components/BagPanel';
import BrandMarquee from './components/BrandMarquee';
import Categories from './components/Categories';
import CustomCursor from './components/CustomCursor';
import Editorial from './components/Editorial';
import FeaturedCollection from './components/FeaturedCollection';
import Footer from './components/Footer';
import Header from './components/Header';
import Hero from './components/Hero';
import InstagramGrid from './components/InstagramGrid';
import Journal from './components/Journal';
import Materials from './components/Materials';
import Newsletter from './components/Newsletter';
import Philosophy from './components/Philosophy';
import ProgressBar from './components/ProgressBar';
import Products from './components/Products';
import StatementTicker from './components/StatementTicker';
import Testimonials from './components/Testimonials';
import Toast from './components/Toast';
import { StoreProvider } from './context/StoreContext';
import { useScrollState } from './hooks';

function Page() {
  const { scrolled, progress } = useScrollState();

  return (
    <div id="top">
      <ProgressBar progress={progress} />
      <CustomCursor />
      <Header scrolled={scrolled} />
      <main>
        <Hero />
        <BrandMarquee />
        <FeaturedCollection />
        <Categories />
        <StatementTicker />
        <Products />
        <Philosophy />
        <Materials />
        <Editorial />
        <Testimonials />
        <Journal />
        <InstagramGrid />
        <Newsletter />
      </main>
      <Footer />
      <Toast />
      <BagPanel />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Page />
    </StoreProvider>
  );
}
