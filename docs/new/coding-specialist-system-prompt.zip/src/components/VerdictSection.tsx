import { SectionShell, SiteTag } from "./ui";

export function VerdictSection() {
  return (
    <SectionShell
      id="verdict"
      eyebrow="Conclusion"
      title="Which design better serves the user?"
      lede="The honest answer depends on the job the visitor showed up to do — but for the stated purpose of both pages, a retail storefront, one clearly serves user needs more completely."
    >
      <div className="grid gap-6 md:grid-cols-5">
        <div className="md:col-span-3 rounded-2xl border border-site-b-line bg-site-b-soft p-7">
          <div className="mb-4 flex items-center justify-between">
            <SiteTag site="b" />
            <span className="font-serif text-3xl text-site-b">Recommended</span>
          </div>
          <p className="text-sm leading-relaxed text-ink">
            <strong>Scandi Haven wins on cohesion and function.</strong> Its
            visual identity is not just attractive but{" "}
            <em>load-bearing</em>: the same terracotta, the same serif, and
            the same spacing rules follow the user from hero to checkout,
            including the moments most sites neglect — an empty cart, a 404,
            a form that needs to say "not yet, but here's what to do
            instead." Every interaction gives feedback. Every link goes
            somewhere real. That is the difference between a beautiful
            picture of a shop and a shop.
          </p>
        </div>
        <div className="md:col-span-2 rounded-2xl border border-site-a-line bg-site-a-soft p-7">
          <div className="mb-4">
            <SiteTag site="a" />
          </div>
          <p className="text-sm leading-relaxed text-ink">
            <strong>MAISON wins on voice.</strong> As a piece of brand
            storytelling — the kind of page a marketing team ships to build
            desire before a product launch — its prose and pacing are more
            confident and specific. But it cannot fulfil the intent it
            creates: every purchase CTA is a dead end, so its compelling
            aesthetic never converts to a compelling <em>experience</em>.
          </p>
        </div>
      </div>

      <div className="mt-6 rounded-xl border border-line bg-paper-soft p-6 text-sm leading-relaxed text-ink-soft">
        <strong className="text-ink">Practical guidance:</strong> if the goal
        is a top-of-funnel brand landing page feeding an external store,
        Site A's copy and pacing are worth borrowing — provided its CTAs are
        wired to real destinations. If the goal is a working storefront,
        Site B is the stronger foundation to extend: fix the leftover brand
        copy, finish the payment integration behind its already-honest
        "coming soon" messaging, and it is close to production-ready as-is.
      </div>
    </SectionShell>
  );
}
