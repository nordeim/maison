export function Footer() {
  return (
    <footer className="border-t border-line py-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-6 text-xs text-ink-faint md:flex-row md:items-center md:justify-between">
        <p>
          Independent UI/UX audit — Site A:{" "}
          <a
            href="https://v1uc168atjn1-d.space-z.ai/landing.html"
            target="_blank"
            rel="noopener noreferrer"
            className="underline decoration-line-strong underline-offset-2 hover:text-clay"
          >
            v1uc168atjn1-d.space-z.ai/landing.html
          </a>{" "}
          · Site B:{" "}
          <a
            href="https://scandi-haven-shop.lovable.app/"
            target="_blank"
            rel="noopener noreferrer"
            className="underline decoration-line-strong underline-offset-2 hover:text-clay"
          >
            scandi-haven-shop.lovable.app
          </a>
        </p>
        <p>Not affiliated with either site or its operators.</p>
      </div>
    </footer>
  );
}
