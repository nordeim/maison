import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

const LINKS = [
  { id: "overview", label: "Overview" },
  { id: "identity", label: "Identity" },
  { id: "interaction", label: "Navigation & UX" },
  { id: "matrix", label: "Comparison" },
  { id: "verdict", label: "Verdict" },
  { id: "methodology", label: "Methodology" },
];

export function Nav() {
  const [active, setActive] = useState("overview");

  useEffect(() => {
    const sections = LINKS.map((l) => document.getElementById(l.id)).filter(
      (el): el is HTMLElement => el !== null,
    );

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-20% 0px -65% 0px", threshold: [0, 0.25, 0.5, 1] },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-4">
        <a href="#overview" className="flex items-baseline gap-2">
          <span className="font-serif text-lg tracking-tight text-ink">
            UX Audit
          </span>
          <span className="hidden text-xs font-medium uppercase tracking-[0.2em] text-ink-faint sm:inline">
            Two Storefronts, Compared
          </span>
        </a>
        <nav aria-label="Report sections" className="flex overflow-x-auto">
          <ul className="flex items-center gap-1 whitespace-nowrap text-sm">
            {LINKS.map((link) => (
              <li key={link.id}>
                <a
                  href={`#${link.id}`}
                  aria-current={active === link.id ? "true" : undefined}
                  className={cn(
                    "rounded-full px-3 py-1.5 font-medium transition-colors",
                    active === link.id
                      ? "bg-ink text-paper"
                      : "text-ink-soft hover:bg-ink/5 hover:text-ink",
                  )}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}
