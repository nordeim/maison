import { ArrowUpRight } from "lucide-react";
import { Eyebrow, SiteTag } from "./ui";

function PaletteRow({ colors }: { colors: string[] }) {
  return (
    <div className="flex h-8 overflow-hidden rounded-lg border border-line">
      {colors.map((color, i) => (
        <div key={i} className="flex-1" style={{ backgroundColor: color }} />
      ))}
    </div>
  );
}

export function Hero() {
  return (
    <section id="overview" className="scroll-mt-24">
      <div className="mx-auto max-w-6xl px-6 pb-16 pt-14 md:pt-20">
        <Eyebrow>Comparative UI/UX Audit — Mode C</Eyebrow>
        <h1 className="mt-4 max-w-3xl font-serif text-4xl leading-[1.1] text-ink md:text-6xl">
          Two Nordic-inspired storefronts.{" "}
          <span className="italic text-clay">One</span> is a beautiful facade.
        </h1>
        <p className="mt-6 max-w-2xl text-base leading-relaxed text-ink-soft md:text-lg">
          A structural review of visual identity, navigation clarity, interaction
          feedback, and cross-device readiness for two live sites, both built
          around a Scandinavian "quiet luxury" home-goods brand. Findings below
          are tagged by confidence — what was verified directly from source vs.
          reasoned from available evidence.
        </p>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {/* Site A */}
          <div className="rounded-2xl border border-line bg-paper-soft p-6 md:p-7">
            <div className="flex items-start justify-between gap-3">
              <SiteTag site="a" />
              <a
                href="https://v1uc168atjn1-d.space-z.ai/landing.html"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs font-medium text-ink-soft hover:text-clay"
              >
                Visit site <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
            <h3 className="mt-4 font-serif text-2xl text-ink">
              "MAISON — Objects of Quiet Beauty"
            </h3>
            <p className="mt-1 text-xs text-ink-faint">
              v1uc168atjn1-d.space-z.ai/landing.html
            </p>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">
              A single static, long-scroll marketing page: editorial hero,
              philosophy story, materials showcase, and testimonials — with no
              underlying shop, cart, or routing.
            </p>
            <div className="mt-5">
              <PaletteRow colors={["#efe9dd", "#d8cdb8", "#3a352d", "#8f6a4a"]} />
              <p className="mt-2 text-[11px] text-ink-faint">
                Illustrative palette — exact tokens unverifiable (see Methodology)
              </p>
            </div>
            <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-[11px] uppercase tracking-wide text-ink-faint">
                  Format
                </dt>
                <dd className="font-medium text-ink">Static single page</dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-wide text-ink-faint">
                  Routes
                </dt>
                <dd className="font-medium text-ink">1 (anchors only)</dd>
              </div>
            </dl>
          </div>

          {/* Site B */}
          <div className="rounded-2xl border border-line bg-paper-soft p-6 md:p-7">
            <div className="flex items-start justify-between gap-3">
              <SiteTag site="b" />
              <a
                href="https://scandi-haven-shop.lovable.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs font-medium text-ink-soft hover:text-clay"
              >
                Visit site <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
            <h3 className="mt-4 font-serif text-2xl text-ink">Scandi Haven</h3>
            <p className="mt-1 text-xs text-ink-faint">
              scandi-haven-shop.lovable.app
            </p>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">
              A full React single-page application with routing, cart state,
              an order-request checkout flow, and scroll-triggered motion —
              built on Tailwind design tokens and shadcn-style primitives.
            </p>
            <div className="mt-5">
              <PaletteRow colors={["#faf8f5", "#f2eee9", "#a65e3f", "#2a2622"]} />
              <p className="mt-2 text-[11px] text-ink-faint">
                Palette derived from published CSS custom properties (verified)
              </p>
            </div>
            <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-[11px] uppercase tracking-wide text-ink-faint">
                  Format
                </dt>
                <dd className="font-medium text-ink">React SPA</dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-wide text-ink-faint">
                  Routes
                </dt>
                <dd className="font-medium text-ink">6 + 404</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}
