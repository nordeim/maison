import { ConfidenceTag, SectionShell } from "./ui";

const ledger = [
  {
    check: "Site A page structure & copy",
    method: "Fetched landing.html and parsed the rendered DOM tree directly.",
    result:
      "Confirmed section order, CTA hrefs, and the absence of an #shop anchor target.",
    confidence: "Verified" as const,
  },
  {
    check: "Site A colors, fonts, and <head>",
    method:
      "Attempted HTML/text extraction; the tool's content pipeline strips <head>, <script>, and class attributes before returning content.",
    result:
      "Could not confirm exact palette, type family, or responsive breakpoints.",
    confidence: "Unverifiable" as const,
  },
  {
    check: "Site B design tokens",
    method: "Fetched the compiled CSS bundle and read the :root custom properties.",
    result:
      "Confirmed HSL values for background, foreground, primary (terracotta), and the full dark-mode variant; confirmed font-family declarations.",
    confidence: "Verified" as const,
  },
  {
    check: "Site B routes, components, and interactions",
    method:
      "Fetched the compiled JavaScript bundle and read the rendered route table, cart logic, form handlers, and animation props.",
    result:
      "Confirmed 6 routes + 404, cart quantity/removal logic, free-shipping threshold, toast on order submission, and framer-motion scroll transitions.",
    confidence: "Verified" as const,
  },
  {
    check: "Site B header/hero markup",
    method: "Same bundle fetch; the response was token-truncated mid-file.",
    result:
      "Home-page hero and header component code were not directly observed; described from route/style evidence and shared design tokens instead.",
    confidence: "Reasoned" as const,
  },
  {
    check: "Rendered visual appearance (screenshots)",
    method: "No headless-browser or screenshot tool was available in this session.",
    result:
      "No claims are made about pixel-level spacing, imagery cropping, or on-screen contrast beyond what source inspection supports.",
    confidence: "Unverifiable" as const,
  },
];

export function MethodologySection() {
  return (
    <SectionShell
      id="methodology"
      eyebrow="Show Your Work"
      title="Methodology & verification ledger"
      lede="Per the audit standard this report follows, every non-trivial claim above is backed by one of the checks below, or explicitly flagged where it couldn't be confirmed."
    >
      <div className="overflow-hidden rounded-2xl border border-line">
        {ledger.map((entry, i) => (
          <div
            key={entry.check}
            className={`grid gap-4 p-6 md:grid-cols-[1fr_1.4fr_1fr_auto] md:items-start ${
              i !== 0 ? "border-t border-line" : ""
            }`}
          >
            <p className="font-medium text-ink">{entry.check}</p>
            <p className="text-sm text-ink-soft">{entry.method}</p>
            <p className="text-sm text-ink-soft">{entry.result}</p>
            <div className="md:justify-self-end">
              <ConfidenceTag level={entry.confidence} />
            </div>
          </div>
        ))}
      </div>

      <p className="mt-6 max-w-3xl text-sm leading-relaxed text-ink-faint">
        Limitations: this review relies on static source, compiled assets,
        and code-level inspection rather than rendered screenshots or a real
        browser session. Where evidence was incomplete, findings are labeled{" "}
        <em>Reasoned</em>, <em>Assumed</em>, or <em>Unverifiable</em> rather
        than presented as confirmed fact.
      </p>
    </SectionShell>
  );
}
