import { Card, Finding, SectionShell, SiteTag } from "./ui";

export function InteractionSection() {
  return (
    <SectionShell
      id="interaction"
      eyebrow="Ease of Use"
      title="Navigation, feedback, and responsiveness"
      lede="A polished surface means little if the paths through it don't hold up. Both sites were inspected at the markup and bundle level for how they route users, confirm actions, and adapt across breakpoints."
    >
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <div className="mb-5">
            <SiteTag site="a" />
          </div>
          <ul className="space-y-3 text-sm leading-relaxed text-ink-soft">
            <li>
              <strong className="text-ink">Navigation model:</strong> in-page
              anchor links only (<code className="rounded bg-ink/5 px-1">#shop</code>,{" "}
              <code className="rounded bg-ink/5 px-1">#story</code>,{" "}
              <code className="rounded bg-ink/5 px-1">#contact</code>). No
              product listing, cart, or checkout route exists.
            </li>
            <li>
              <strong className="text-ink">Feedback:</strong> the newsletter
              field and CTA buttons are the only interactive elements found;
              no visible confirmation, loading, or error states in the markup.
            </li>
            <li>
              <strong className="text-ink">Responsiveness:</strong> cannot be
              verified — the extraction tooling strips class attributes and
              the document &lt;head&gt;, so breakpoint behavior and viewport
              meta configuration are unknown.
            </li>
            <li>
              <strong className="text-ink">Content completeness:</strong>{" "}
              several sections are scaffolded but empty: a marquee, a
              statement ticker, a "Featured Products" grid, and a journal
              block all exist as markers with no rendered content.
            </li>
          </ul>
        </Card>

        <Card>
          <div className="mb-5">
            <SiteTag site="b" />
          </div>
          <ul className="space-y-3 text-sm leading-relaxed text-ink-soft">
            <li>
              <strong className="text-ink">Navigation model:</strong> client-side
              routing across six named routes plus a 404 fallback, with a
              persistent header/cart affordance implied by shared layout
              components across pages.
            </li>
            <li>
              <strong className="text-ink">Feedback:</strong> quantity steppers,
              a remove-from-cart action, a live order summary (subtotal,
              conditional free shipping, total), and a toast notification on
              order submission ("Order Request Submitted").
            </li>
            <li>
              <strong className="text-ink">Responsiveness:</strong> Tailwind
              responsive utilities (<code className="rounded bg-ink/5 px-1">sm:</code>,{" "}
              <code className="rounded bg-ink/5 px-1">md:</code>,{" "}
              <code className="rounded bg-ink/5 px-1">lg:</code>) are applied
              throughout — grid columns, spacing, and sticky panels all adapt
              per breakpoint.
            </li>
            <li>
              <strong className="text-ink">Motion &amp; states:</strong>{" "}
              scroll-triggered fade/slide transitions on every major section,
              plus explicit empty-cart, empty-checkout, and 404 states with
              helpful calls to action.
            </li>
          </ul>
        </Card>
      </div>

      <h3 className="mt-12 mb-5 font-serif text-xl text-ink">
        Notable findings
      </h3>
      <div className="grid gap-4 md:grid-cols-2">
        <Finding severity="High" confidence="Verified" title="Dead primary CTAs (Site A)">
          "Shop Lighting," "Shop the Hygge Edit," and "View all categories"
          all link to <code className="rounded bg-ink/5 px-1">#shop</code>.
          No element with <code className="rounded bg-ink/5 px-1">id="shop"</code>{" "}
          exists in the page source — every purchase-intent action is a dead
          link with no fallback.
        </Finding>
        <Finding severity="Medium" confidence="Reasoned" title="Unfinished content blocks (Site A)">
          Marquee, statement-ticker, featured-products, and journal sections
          are marked in the source but render no content, suggesting an
          incomplete build shipped as if final.
        </Finding>
        <Finding severity="Medium" confidence="Verified" title="Non-functional checkout, disclosed honestly (Site B)">
          Checkout collects an order request rather than processing payment,
          but this is stated plainly in a banner ("Online checkout coming
          soon") instead of being hidden — a trust-preserving pattern Site A
          does not offer, since it never reaches a checkout at all.
        </Finding>
        <Finding severity="Low" confidence="Verified" title="Brand-name leakage (Site B)">
          The storefront is branded "Scandi Haven" in its domain, but internal
          copy and the contact link still read{" "}
          <code className="rounded bg-ink/5 px-1">hello@maison.com</code> —
          leftover placeholder content from an unlocalized template.
        </Finding>
      </div>
    </SectionShell>
  );
}
