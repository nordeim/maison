import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export type Confidence = "Verified" | "Reasoned" | "Assumed" | "Unverifiable";

const confidenceStyles: Record<Confidence, string> = {
  Verified: "bg-site-b-soft text-site-b border-site-b-line",
  Reasoned: "bg-clay-soft text-clay-dark border-clay/30",
  Assumed: "bg-site-a-soft text-site-a border-site-a-line",
  Unverifiable: "bg-ink/5 text-ink-faint border-line-strong",
};

export function ConfidenceTag({ level }: { level: Confidence }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em]",
        confidenceStyles[level],
      )}
    >
      {level}
    </span>
  );
}

export function SiteTag({ site }: { site: "a" | "b" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.14em]",
        site === "a"
          ? "border-site-a-line bg-site-a-soft text-site-a"
          : "border-site-b-line bg-site-b-soft text-site-b",
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full",
          site === "a" ? "bg-site-a" : "bg-site-b",
        )}
      />
      Site {site === "a" ? "A" : "B"}
    </span>
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-clay">
      {children}
    </p>
  );
}

export function SectionShell({
  id,
  eyebrow,
  title,
  lede,
  children,
}: {
  id: string;
  eyebrow: string;
  title: ReactNode;
  lede?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 border-t border-line py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mb-12 max-w-2xl">
          <Eyebrow>{eyebrow}</Eyebrow>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-ink md:text-4xl">
            {title}
          </h2>
          {lede ? (
            <p className="mt-4 text-[15px] leading-relaxed text-ink-soft">{lede}</p>
          ) : null}
        </div>
        {children}
      </div>
    </section>
  );
}

export function Card({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-line bg-paper-soft p-6 md:p-8",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Finding({
  severity,
  confidence,
  title,
  children,
}: {
  severity: "Critical" | "High" | "Medium" | "Low" | "Informational";
  confidence: Confidence;
  title: string;
  children: ReactNode;
}) {
  const severityStyles: Record<typeof severity, string> = {
    Critical: "border-red-300 bg-red-50 text-red-700",
    High: "border-clay/40 bg-clay-soft text-clay-dark",
    Medium: "border-site-a-line bg-site-a-soft text-site-a",
    Low: "border-line-strong bg-ink/5 text-ink-soft",
    Informational: "border-line bg-paper text-ink-faint",
  };
  return (
    <div className="rounded-xl border border-line bg-paper-soft p-5">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <span
          className={cn(
            "rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em]",
            severityStyles[severity],
          )}
        >
          {severity}
        </span>
        <ConfidenceTag level={confidence} />
      </div>
      <h4 className="font-serif text-lg text-ink">{title}</h4>
      <div className="mt-1.5 text-sm leading-relaxed text-ink-soft">{children}</div>
    </div>
  );
}
