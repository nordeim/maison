import { Card, ConfidenceTag, SectionShell, SiteTag } from "./ui";

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="border-t border-line py-4 first:border-t-0 first:pt-0">
      <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-faint">
        {label}
      </p>
      <div className="mt-2 text-sm leading-relaxed text-ink-soft">{children}</div>
    </div>
  );
}

export function IdentitySection() {
  return (
    <SectionShell
      id="identity"
      eyebrow="Form & Function"
      title="How each site presents its identity"
      lede="Color, typography, and layout are the fastest signals of brand intent. One site commits to a single editorial voice; the other exposes its full design system — tokens, type scale, and dark-mode variant included."
    >
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <div className="mb-5 flex items-center justify-between">
            <SiteTag site="a" />
            <ConfidenceTag level="Reasoned" />
          </div>
          <Row label="Color">
            Warm, neutral editorial tones inferred from photography (linen,
            oak, brass) and copy ("Objects of Quiet Beauty"). No stylesheet
            was retrievable, so exact hex values, contrast ratios, and dark-mode
            support cannot be confirmed either way.
          </Row>
          <Row label="Typography">
            Headlines use italicized emphasis words within serif-styled
            headings ("casts <em>warmth</em>", "made with <em>care</em>"),
            suggesting a serif/sans pairing typical of editorial retail. Font
            family and weight scale are unverifiable without page &lt;head&gt;
            access.
          </Row>
          <Row label="Layout">
            A single vertical scroll: announcement bar → hero → featured
            collection → category grid → philosophy triptych → materials →
            editorial banner → testimonials → newsletter. Generous imagery,
            alternating text/image rhythm, magazine-style pacing.
          </Row>
        </Card>

        <Card>
          <div className="mb-5 flex items-center justify-between">
            <SiteTag site="b" />
            <ConfidenceTag level="Verified" />
          </div>
          <Row label="Color">
            A defined HSL token system: warm cream background (
            <code className="rounded bg-ink/5 px-1">40 33% 97%</code>), charcoal
            foreground, and a terracotta primary (
            <code className="rounded bg-ink/5 px-1">18 45% 45%</code>) reused
            across buttons, links, and hover states — plus a complete
            dark-mode token set, unused in the current UI but present in code.
          </Row>
          <Row label="Typography">
            Cormorant Garamond (serif, headings, italic accents) paired with
            Inter (sans, body/UI) — a conventional but well-executed
            luxury-retail pairing, applied consistently via CSS variables
            rather than ad hoc classes.
          </Row>
          <Row label="Layout">
            Six routed views (Home, Products, Product detail, About, Cart,
            Checkout) sharing a persistent header/footer shell, Tailwind
            container utilities, and a 12-column grid for editorial sections —
            a true system rather than one bespoke page.
          </Row>
        </Card>
      </div>

      <div className="mt-6 rounded-xl border border-clay/30 bg-clay-soft p-5 text-sm leading-relaxed text-clay-dark">
        <strong className="font-semibold">Read on harmony:</strong> Site A's
        identity is more evocative in prose — the copywriting alone does real
        design work. Site B's identity is more <em>provable</em>: it is
        expressed as reusable tokens, so the same terracotta and the same
        serif show up identically on every screen, including states Site A
        never reaches (empty cart, 404, checkout).
      </div>
    </SectionShell>
  );
}
