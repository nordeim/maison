import { Check, Minus, TriangleAlert, X } from "lucide-react";
import { SectionShell, SiteTag } from "./ui";

type Status = "pass" | "partial" | "fail" | "na";

const statusIcon: Record<Status, React.ReactNode> = {
  pass: <Check className="h-4 w-4 text-site-b" />,
  partial: <TriangleAlert className="h-4 w-4 text-site-a" />,
  fail: <X className="h-4 w-4 text-clay-dark" />,
  na: <Minus className="h-4 w-4 text-ink-faint" />,
};

interface Row {
  dimension: string;
  a: { status: Status; note: string };
  b: { status: Status; note: string };
}

const rows: Row[] = [
  {
    dimension: "Coherent visual identity",
    a: { status: "partial", note: "Strong voice; unverifiable system" },
    b: { status: "pass", note: "Tokenized colors + type scale" },
  },
  {
    dimension: "Working navigation to a product",
    a: { status: "fail", note: "CTAs link to a nonexistent anchor" },
    b: { status: "pass", note: "Home → Products → Product detail" },
  },
  {
    dimension: "Cart & checkout flow",
    a: { status: "na", note: "Not present" },
    b: { status: "partial", note: "Order request, not live payment" },
  },
  {
    dimension: "Interactive feedback (loading/confirm/error)",
    a: { status: "fail", note: "No confirmations observed" },
    b: { status: "pass", note: "Toasts, stepper states, disabled states" },
  },
  {
    dimension: "Responsive breakpoint system",
    a: { status: "na", note: "Unverifiable from source" },
    b: { status: "pass", note: "sm/md/lg utilities throughout" },
  },
  {
    dimension: "Empty & edge states designed",
    a: { status: "fail", note: "No cart/404 to evaluate" },
    b: { status: "pass", note: "Empty cart, empty checkout, 404" },
  },
  {
    dimension: "Content depth / editorial storytelling",
    a: { status: "pass", note: "Philosophy, materials, testimonials" },
    b: { status: "partial", note: "Present but thinner per section" },
  },
  {
    dimension: "Production hygiene (no dead scaffolding)",
    a: { status: "fail", note: "Empty ticker/journal/product blocks" },
    b: { status: "partial", note: "Stray placeholder brand copy" },
  },
];

export function MatrixSection() {
  return (
    <SectionShell
      id="matrix"
      eyebrow="Side by Side"
      title="Feature & experience matrix"
      lede="A single scorecard rarely tells the truth. This matrix separates what each site attempts from how completely it delivers it."
    >
      <div className="overflow-x-auto rounded-2xl border border-line">
        <table className="w-full min-w-[640px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-line bg-paper-soft text-left">
              <th className="px-5 py-4 font-medium text-ink-faint">Dimension</th>
              <th className="px-5 py-4">
                <SiteTag site="a" />
              </th>
              <th className="px-5 py-4">
                <SiteTag site="b" />
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.dimension} className="border-b border-line last:border-b-0">
                <td className="px-5 py-4 font-medium text-ink">{row.dimension}</td>
                <td className="px-5 py-4">
                  <div className="flex items-start gap-2">
                    {statusIcon[row.a.status]}
                    <span className="text-ink-soft">{row.a.note}</span>
                  </div>
                </td>
                <td className="px-5 py-4">
                  <div className="flex items-start gap-2">
                    {statusIcon[row.b.status]}
                    <span className="text-ink-soft">{row.b.note}</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex flex-wrap gap-4 text-xs text-ink-faint">
        <span className="flex items-center gap-1.5">
          <Check className="h-3.5 w-3.5 text-site-b" /> Pass
        </span>
        <span className="flex items-center gap-1.5">
          <TriangleAlert className="h-3.5 w-3.5 text-site-a" /> Partial
        </span>
        <span className="flex items-center gap-1.5">
          <X className="h-3.5 w-3.5 text-clay-dark" /> Fail
        </span>
        <span className="flex items-center gap-1.5">
          <Minus className="h-3.5 w-3.5 text-ink-faint" /> Not applicable / unverifiable
        </span>
      </div>
    </SectionShell>
  );
}
