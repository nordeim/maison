import { Footer } from "./components/Footer";
import { Hero } from "./components/Hero";
import { IdentitySection } from "./components/IdentitySection";
import { InteractionSection } from "./components/InteractionSection";
import { MatrixSection } from "./components/MatrixSection";
import { MethodologySection } from "./components/MethodologySection";
import { Nav } from "./components/Nav";
import { VerdictSection } from "./components/VerdictSection";

export default function App() {
  return (
    <div className="min-h-screen bg-paper text-ink">
      <Nav />
      <main>
        <Hero />
        <IdentitySection />
        <InteractionSection />
        <MatrixSection />
        <VerdictSection />
        <MethodologySection />
      </main>
      <Footer />
    </div>
  );
}
