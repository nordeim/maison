import { db } from "@/db";
import { sql } from "drizzle-orm";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  // Verify PostgreSQL connectivity before serving the landing experience.
  await db.execute(sql`select 1`);

  // The redesigned "MAISON" landing page mock-up lives as a static,
  // self-contained HTML artifact (see /public/landing.html) so it can be
  // reviewed independently of the Next.js/React rendering pipeline.
  redirect("/landing.html");
}
