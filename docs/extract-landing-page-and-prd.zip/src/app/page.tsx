import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await db.execute(sql`select 1`);

  return (
    <main className="grid min-h-screen place-items-center px-6 py-12">
      <section className="w-full max-w-2xl rounded-3xl bg-white p-10 shadow-[0_24px_60px_rgba(16,24,40,0.12)]">
        <p className="m-0 text-sm uppercase tracking-[0.08em] text-slate-600">Maison — Extraction Deliverables</p>
        <h1 className="mt-4 text-[clamp(2rem,5vw,3.25rem)] font-semibold leading-[1.05] text-slate-950">
          Scandi Haven Shop, extracted
        </h1>
        <p className="mt-4 text-base text-slate-700">
          A single self-contained HTML clone of the live landing page, plus a full production PRD, were produced
          for this request.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <a
            href="/scandi-haven-landing.html"
            className="inline-flex items-center justify-center rounded-full bg-slate-950 px-6 py-3 text-sm font-medium text-white transition hover:bg-slate-800"
          >
            View extracted landing page
          </a>
        </div>
        <p className="mt-4 text-sm text-slate-500">
          The full PRD document is available in the repository as <code className="rounded bg-slate-100 px-1.5 py-0.5">PRD.md</code>.
        </p>
      </section>
    </main>
  );
}
